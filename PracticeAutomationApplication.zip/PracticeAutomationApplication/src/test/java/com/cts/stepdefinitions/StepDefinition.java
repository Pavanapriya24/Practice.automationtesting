package com.cts.stepdefinitions;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cts.pages.LogoutAccount;
import com.cts.pages.MyAccount;
import com.cts.pages.RegisterAccount;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition {
	

	 public WebDriver driver;
	 
	 


	 @Given("User launch the browser with practiceautomationtestingPage")
	 public void user_launch_the_browser_with_practiceautomationtestingPage() {
	 System.setProperty("webdriver.chrome.driver", "src/main/resources/driver/chromedriver.exe");
	 System.out.println("Given");
	 driver = new ChromeDriver();
	 driver.manage().window().maximize();
	 driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	 driver.get("http://practice.automationtesting.in/");

	 }

	 @When("I click on my account link and enter registerusername as {string} and I enter registerpassword as {string}")
	 public void i_click_on_my_account_link_and_enter_registerusername_as_and_I_enter_registerpassword_as(String registerusername, String registerpassword) {
	 MyAccount.clickOnMyAccount(driver);
	 RegisterAccount.enterUsername(driver, registerusername);
	 RegisterAccount.enterPassword(driver, registerpassword);


	 }

	 @When("click on register button")
	 public void click_on_register_button() {
	     RegisterAccount.clickOnRegister(driver);
	 }

	@Then("i should access browser page")
	 public void i_should_access_browser_page() {
		 System.out.println("then");  
	 }



	 

   @When("I click on login button and enter loginusername as {string} and I enter loginpassword as {string}")
	  public void i_click_on_login_button_and_enter_loginusername_as_and_I_enter_loginpassword_as(String emailname, String loginpassword) {
	 MyAccount.clickOnMyAccount(driver);
	    RegisterAccount.enterEmail(driver, emailname);
	 RegisterAccount.enterLoginPassword(driver, loginpassword);
	
	  }

	  @When("click on login button")
	  public void click_on_login_button() {
	 RegisterAccount.clickOnLogin(driver);
	  }

	  @Then("I should get access to home page  browser")
	  public void i_should_get_access_to_home_page_browser() {
	 System.out.println("then");
	  }

	  @When("I click on my account and enter loginusername as {string} and I enter loginpassword as {string}")
	  public void i_click_on_my_account_and_enter_loginusername_as_and_I_enter_loginpassword_as(String emailname, String loginpassword) {
		  MyAccount.clickOnMyAccount(driver);
		    RegisterAccount.enterEmail(driver, emailname);
		 RegisterAccount.enterLoginPassword(driver, loginpassword);
	  }


	  @When("click on login")
	  public void click_on_login() {
	 RegisterAccount.clickOnLogin(driver);
	  }

	  @Then("I should get user could not be found using this email")
	  public void i_should_get_user_could_not_be_found_using_this_email() {
		  System.out.println("then");    
	  }



	  
	  @When("I click on my account and enter inregisterusername as {string} and I enter registerpassword as {string}")
	  public void i_click_on_my_account_and_enter_inregisterusername_as_and_I_enter_registerpassword_as(String registerusername, String registerpassword) {
		  MyAccount.clickOnMyAccount(driver);
			 RegisterAccount.enterUsername(driver, registerusername);
			 RegisterAccount.enterPassword(driver, registerpassword);
	  }

	  @When("click on register")
	  public void click_on_register() {
	      RegisterAccount.clickOnRegister(driver);
	  }

	  @Then("I should get error")
	  public void i_should_get_error() {
		  System.out.println("then");  
	  }
	  @When("click on loginbutton")
	  public void click_on_loginbutton() {
	     RegisterAccount.clickOnLogin(driver);
	  }


      @Then("I should get main page")
	  public void i_should_get_main_page() {
	  System.out.println("then");
	  }


	  
}		