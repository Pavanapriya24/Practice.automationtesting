package com.cts.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class LogoutAccount {
	
	public static By clickOnLogOutLoc = By.xpath("//a[text()='Logout']");
	
	
	public static void clickOnLogOut(WebDriver driver)
	{
		driver.findElement(clickOnLogOutLoc).click();
	}
	
	
		

}
